<!-- books/index.blade.php -->




    <h1>Books</h1>
    
    @foreach ($books as $book)
        <div>
            <h3>{{ $book->book_name }}</h3>
            <p>Publisher: {{ $book->publisher_name }}</p>
            <p>Page Count: {{ $book->page_no }}</p>
            <p>Book Published Date: {{ $book->publish_date }}</p>
            <p>Book Type: {{ $book->book_type }}</p>
            <!-- Add other book details as needed -->
        </div>
    @endforeach

    {{ $books->links() }} <!-- Display pagination links -->


