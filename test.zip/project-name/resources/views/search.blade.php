<form method="GET" action="{{ route('books.index') }}">
    <div>
        <label for="keyword">Keyword:</label>
        <input type="text" name="keyword" id="keyword" value="{{ request('keyword') }}">
    </div>
    <div>
        <label for="age">Age:</label>
        <select name="age" id="age">
            <option value="">Any</option>
            <option value="10" {{ request('age') == '10' ? 'selected' : '' }}>10</option>
            <option value="20" {{ request('age') == '20' ? 'selected' : '' }}>20</option>
            <option value="30" {{ request('age') == '30' ? 'selected' : '' }}>30</option>
        </select>
    </div>
    <div>
        <label>Book Type:</label>
        <div>
            <input type="checkbox" name="book_type[]" value="Scifi" {{ in_array('Scifi', request('book_type', [])) ? 'checked' : '' }}>
            <label for="book_type_scifi">Sci-Fi</label>
        </div>
        <div>
            <input type="checkbox" name="book_type[]" value="drama" {{ in_array('drama', request('book_type', [])) ? 'checked' : '' }}>
            <label for="book_type_drama">Drama</label>
        </div>
        <div>
            <input type="checkbox" name="book_type[]" value="Novel" {{ in_array('Novel', request('book_type', [])) ? 'checked' : '' }}>
            <label for="book_type_novel">Novel</label>
        </div>
    </div>
    <div>
        <button type="submit">Search</button>
    </div>
</form>
