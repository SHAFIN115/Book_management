<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class BookController extends Controller
{
    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'book_name' => 'required',
            'publisher_name' => 'required',
            'publisher_age' => 'required|integer',
            'page_no' => 'required|integer',
            'publish_date' => 'required|date',
            'book_type' => 'required'
        ]);

        // Create a new book instance
        $book = new Book;
        $book->book_name = $validatedData['book_name'];
        $book->publisher_name = $validatedData['publisher_name'];
        $book->publisher_age = $validatedData['publisher_age'];
        $book->page_no = $validatedData['page_no'];
        $book->publish_date = $validatedData['publish_date'];
        $book->book_type = $validatedData['book_type'];

        // Save the book to the database
        $book->save();

        // Redirect the user after successful storage
        return redirect()->back()->with('success', 'Book saved successfully.');
    }
    public function index()
    {
        $books = Book::paginate(10); // Retrieve paginated books from the database

        return view('index', compact('books'));

    }
    public function search(Request $request)
    {
        $query = Book::query();

        // Retrieve the search parameters from the request
        $keyword = $request->input('keyword');
        $age = $request->input('age');
        $bookTypes = $request->input('book_type');

        // Apply filters based on the search parameters
        if ($keyword) {
            $query->where('book_name', 'like', '%' . $keyword . '%');
        }

        if ($age) {
            $query->where('publisher_age', $age);
        }

        if ($bookTypes) {
            $query->whereIn('book_type', $bookTypes);
        }

        $books = $query->paginate(10);

        return view('search', compact('books'));
    }

}