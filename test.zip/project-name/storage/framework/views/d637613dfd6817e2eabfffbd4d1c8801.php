<form method="POST" action="<?php echo e(route('books.store')); ?>">
    <?php echo csrf_field(); ?>
    <div>
        <label for="book_name">Book Name:</label>
        <input type="text" name="book_name" id="book_name" required>
    </div>
    <div>
        <label for="publisher_name">Publisher Name:</label>
        <input type="text" name="publisher_name" id="publisher_name" required>
    </div>
    <div>
        <label for="publisher_age">Publisher Age:</label>
        <input type="number" name="publisher_age" id="publisher_age" required>
    </div>
    <div>
        <label for="page_no">Page Number:</label>
        <input type="number" name="page_no" id="page_no" required>
    </div>
    <div>
        <label for="publish_date">Publish Date:</label>
        <input type="date" name="publish_date" id="publish_date" required>
    </div>
    <div>
        <label for="book_type">Book Type:</label>
        <select name="book_type" id="book_type" required>
            <option value="Scifi">Sci-Fi</option>
            <option value="drama">Drama</option>
            <option value="Novel">Novel</option>
        </select>
    </div>
    <div>
        <button type="submit">Save</button>
    </div>
</form>
<?php /**PATH C:\Users\Admin\Desktop\Practical_test\project-name\resources\views/create.blade.php ENDPATH**/ ?>