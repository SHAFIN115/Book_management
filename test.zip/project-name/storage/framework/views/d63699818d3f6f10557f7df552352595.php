<!-- books/index.blade.php -->




    <h1>Books</h1>
    
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <h3><?php echo e($book->book_name); ?></h3>
            <p>Publisher: <?php echo e($book->publisher_name); ?></p>
            <p>Page Count: <?php echo e($book->page_no); ?></p>
            <p>Book Published Date: <?php echo e($book->publish_date); ?></p>
            <p>Book Type: <?php echo e($book->book_type); ?></p>
            <!-- Add other book details as needed -->
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($books->links()); ?> <!-- Display pagination links -->


<?php /**PATH C:\Users\Admin\Desktop\Practical_test\project-name\resources\views/index.blade.php ENDPATH**/ ?>